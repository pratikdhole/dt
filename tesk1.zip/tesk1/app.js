const dt = (a,b) => a+b;

module.exports= {
    dt,
}