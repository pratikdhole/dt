let x = 23;
(function (){
    let twice = x*2;
    console.log(twice);
}());