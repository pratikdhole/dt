var mynm;

mynm='nme';
console.log(mynm);

// ===========================
// let and const

function abc(){

}
//  let 
if (true){
    let mynm = 'my name is';
    console.log(mynm);
}

console.log(mynm);


// const
const mynm = "my name is prarik";
mynm = "not my nme";
console.log(mynm)

let dt = [1,2,3,4];

let data = dt.filter(Element => dt);
console.log(data);


const abc = (a,b)=> (1,2);

