const { dt } = require("./app");


// http.createServer(function (req, res) {
//   res.writeHead(200, {'Content-Type': 'text/html'});
//   res.end('Hello World!');
// }).listen(8080);



console.log(dt(2,2));

// for(i=0;i<100;i++){
// console.log(i);
// let b = i.filter(i => i.length>45);
// console.log(b);
// }

